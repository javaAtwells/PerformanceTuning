package com.javapassion.examples.account.controllers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.javapassion.examples.account.domain.Account;

@Controller
@RequestMapping(value="/accounts")
public class AccountController {

	private Map<Long, Account> accountMap = new ConcurrentHashMap<Long, Account>();
	
	@RequestMapping(method=RequestMethod.GET)
	public String getAccounts(Model model) {
		// Add some test data
		Account account = new Account( new Long(0001), "Sang Shin", new BigDecimal("1000"), new BigDecimal("0.60"), new Date());
		accountMap.put(new Long(0001), account);
		account =  new Account( new Long(0002), "Daniel Shin", new BigDecimal("2000"), new BigDecimal("0.60"), new Date());
		accountMap.put(new Long(0002), account);
		account =  new Account( new Long(0003), "Tommy Jones", new BigDecimal("3000"), new BigDecimal("0.70"), new Date());
		accountMap.put(new Long(0003), account);
		
		// Add "accounts" attribute to the model
		model.addAttribute("accounts", new ArrayList<Account>(accountMap.values()));
		return "accounts";
	}
	
	@RequestMapping(value="{id}", method=RequestMethod.GET)
	public String getView(@PathVariable Long id, Model model) {
		Account account = this.accountMap.get(id);
		if (account == null) {
			throw new ResourceNotFoundException(id);
		}
		model.addAttribute(account);
		return "account";
	}

}
