/*
 * Copyright 2002-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.javapassion.examples.account.views;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.feed.AbstractRssFeedView;

import com.javapassion.examples.account.domain.Account;
import com.sun.syndication.feed.rss.Channel;
import com.sun.syndication.feed.rss.Item;

public class AccountRssView extends AbstractRssFeedView {

	// Populate the feed metadata (title, link, description, etc.). 
	@Override
	protected void buildFeedMetadata(Map<String, Object> model, Channel feed,
			HttpServletRequest request) {
		feed.setTitle("List of Accounts");
		feed.setDescription("RSS feed testing");
		feed.setLink("javapassion.com");

		@SuppressWarnings("unchecked")
		List<Account> accountList = (List<Account>) model.get("accounts");

		for (Account account : accountList) {
			Date date = account.getRenewalDate();
			if ((feed.getLastBuildDate() == null)
					|| (date.compareTo(feed.getLastBuildDate()) > 0)) {
				feed.setLastBuildDate(date);
			}
		}
	}

	// Build feed items from accounts
	protected List buildFeedItems(Map model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<Account> accountList = 
			(List<Account>) model.get("accounts");
		List<Item> items = new ArrayList<Item>(accountList.size());

		for (Account account : accountList) {
			Item item = new Item();
			String date = String.format("%1$tY-%1$tm-%1$td",
					account.getRenewalDate());
			item.setAuthor(account.getName());
			item.setTitle(String.format("%s - Posted by %s",
					account.getName(), account.getName()));
			item.setPubDate(account.getRenewalDate());
			item.setLink("http://www.javapassion.com");
			items.add(item);
		}

		return items;
	}

}
