package helloworld;

import com.sun.jersey.core.util.Base64;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;

@Path("/HelloWorld")
public class Hello {

    @GET
    @Produces("text/plain")
    @RolesAllowed("user")
    public String getNumber(@Context HttpHeaders headers) {
        System.out.println(getCredentials(headers));

        return "Secured with user role";
    }

    @GET
    @Path("/secure")
    @RolesAllowed("admin")
    @Produces("text/plain")
    public String getSecureNumber(@Context HttpHeaders headers) {
        System.out.println(getCredentials(headers));

        return "Secured with admin role";
    }

    private String getCredentials(HttpHeaders headers) {
        String auth = headers.getRequestHeader("authorization").get(0);

        auth = auth.substring("Basic ".length());
        String[] values = new String(Base64.base64Decode(auth)).split(":");
        String username = values[0];
        String password = values[1];

        String return_val = "Username = " + username + " Password = " + password;

        return return_val;
    }

}
