package helloworld;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

// Will respond to http://example.com/users/?username=JohnMist
@Path("/users")
public class HelloWorldResource {

    @GET
    //  In order to obtain the value of the username variable, @QueryParam 
    //  is used on a method parameter 
    public Response getUser(@QueryParam("username") String userName) {
        // �userName� variable has value of �JohnMist�
        String output = "User's name is " + userName;
        return Response.status(200).entity(output).build();
    }
}
