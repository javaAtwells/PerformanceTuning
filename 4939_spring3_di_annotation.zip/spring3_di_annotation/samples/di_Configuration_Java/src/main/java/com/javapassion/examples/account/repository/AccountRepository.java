package com.javapassion.examples.account.repository;

import java.util.Set;

import com.javapassion.examples.account.domain.Account;

public interface AccountRepository {

	Account findById(String acctId);

	void update(Account account);

	void add(Account account);

	Set<Account> findAll();

}
