package com.javapassion.examples.services;

public interface CustomerService {
	public String getCustomerGreeting();
}
