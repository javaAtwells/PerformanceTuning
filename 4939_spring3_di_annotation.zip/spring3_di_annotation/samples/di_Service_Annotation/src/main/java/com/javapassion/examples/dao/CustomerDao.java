package com.javapassion.examples.dao;

public interface CustomerDao {
	public String getCustomerName();
}
