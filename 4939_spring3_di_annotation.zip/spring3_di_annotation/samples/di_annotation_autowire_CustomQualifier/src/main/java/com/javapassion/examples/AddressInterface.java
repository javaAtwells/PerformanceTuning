package com.javapassion.examples;

public interface AddressInterface {
	String getWholeAddress();
}
