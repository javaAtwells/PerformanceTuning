package com.javapassion.examples.dao;

public class CustomerDaoImpl implements CustomerDao {
	
	public String getCustomerName() {
		// For the sake of simplicity, return hard-coded custome rname
		return "Sang Shin"; 
	}
}
