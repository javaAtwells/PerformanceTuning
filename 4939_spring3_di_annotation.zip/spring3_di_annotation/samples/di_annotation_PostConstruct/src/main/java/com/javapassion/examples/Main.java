package com.javapassion.examples;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext factory = new ClassPathXmlApplicationContext("/beans.xml");

		Person person = (Person) factory.getBean("person");
		System.out.println(getPersonInfo(person));
		
		factory.close();
	}

	public static String getPersonInfo(Person person) {
		return "Name:" + person.getName() + "\n" + "Age:" + person.getAge()
				+ "\n" + "Height: " + person.getHeight() + "\n"
				+ "Is Programmer?: " + person.isProgrammer() + "\n"
				+ "Address: " + person.getAddress().getStreetNumber() + " "
				+ person.getAddress().getStreetName() + " "
				+ person.getAddress().getCity() + " "
				+ person.getAddress().getCountry();
	}
}